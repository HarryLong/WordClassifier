#pragma once

class Settings{
public:
  static unsigned int sGlobalEliminationThreshold;
  static unsigned int sStartEliminationThreshold;
  static unsigned int sEndEliminationThreshold;
  static bool sNormalize;
};
