#include "settings.h"

unsigned int Settings::sGlobalEliminationThreshold = 10;
unsigned int Settings::sStartEliminationThreshold = 100;
unsigned int Settings::sEndEliminationThreshold = 100;
bool Settings::sNormalize = true;
